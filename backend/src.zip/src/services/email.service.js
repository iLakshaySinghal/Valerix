const sendEmail = require("../utils/sendEmail");

async function sendOTPEmail(to, otp) {
  const subject = "Your Login OTP";
  const text = `Your OTP is: ${otp}. It is valid for 5 minutes.`;

  await sendEmail(to, subject, text);
  return true;
}

module.exports = { sendOTPEmail };
