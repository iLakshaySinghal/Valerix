const User = require("../models/User");
const { generateOTP, hashOTP, isOTPExpired } = require("../utils/otp.util");
const { sendOTPEmail } = require("./email.service");
const { signPayload } = require("../config/jwt");

class AuthService {

  // ================================
  // STEP 1 → REQUEST OTP
  // ================================
  static async requestOTP(email, phone, requestedRole = "user", requesterRole = "user") {

    // ------------------------------------------
    // ROLE VALIDATION RULES
    // ------------------------------------------

    let finalRole = "user";

    // ONLY ADMIN CAN CREATE ADMIN
    if (requestedRole === "admin") {
      if (requesterRole !== "admin") {
        throw new Error("Only an admin can assign admin role.");
      }
      finalRole = "admin";
    }

    // ANYONE CAN REGISTER AS STARTUP
    else if (requestedRole === "startup") {
      finalRole = "startup";
    }

    // DEFAULT USER
    else {
      finalRole = "user";
    }

    // ------------------------------------------
    // FIND OR CREATE USER
    // ------------------------------------------
    let user = await User.findOne({ $or: [{ email }, { phone }] });

    if (!user) {
      user = await User.create({
        email,
        phone,
        role: finalRole
      });
    } else {
      // If updating role, follow same rules
      if (requestedRole === "admin" && requesterRole !== "admin") {
        throw new Error("Only an admin can promote a user to admin.");
      }

      user.role = finalRole;
    }

    // ------------------------------------------
    // GENERATE OTP
    // ------------------------------------------
    const otp = generateOTP();
    const hashed = hashOTP(otp);

    user.otpHash = hashed;
    user.otpExpiresAt = new Date(Date.now() + 5 * 60 * 1000); // 5 min
    await user.save();

    await sendOTPEmail(email, otp);

    return {
      success: true,
      message: "OTP sent successfully",
      assignedRole: finalRole
    };
  }

  // ================================
  // STEP 2 → VERIFY OTP
  // ================================
  static async verifyOTP(email, otp) {
    const user = await User.findOne({ email });
    if (!user) throw new Error("User not found");

    if (!user.otpHash) throw new Error("OTP not requested");
    if (isOTPExpired(user.otpExpiresAt)) throw new Error("OTP expired");

    const hashed = hashOTP(otp);
    if (hashed !== user.otpHash) throw new Error("Invalid OTP");

    user.otpHash = undefined;
    user.otpExpiresAt = undefined;
    user.isVerified = true;
    await user.save();

    const token = signPayload({
      id: user._id,
      email: user.email,
      role: user.role,
    });

    return {
      success: true,
      token,
      user: {
        id: user._id,
        email: user.email,
        role: user.role
      }
    };
  }
}

module.exports = AuthService;
