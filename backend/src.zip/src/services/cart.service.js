const Cart = require("../models/Cart");
const Product = require("../models/Product");

class CartService {

  // Get or create user cart
  static async getOrCreateCart(userId) {
    let cart = await Cart.findOne({ userId });
    if (!cart) {
      cart = await Cart.create({ userId, items: [] });
    }
    return cart;
  }

  // Get user cart with product details
  static async getCart(userId) {
    const cart = await Cart.findOne({ userId })
      .populate("items.productId", "name price images ownerId");
    return cart || { items: [] };
  }

  // Add product to cart
  static async addToCart(userId, productId, quantity) {
    const cart = await CartService.getOrCreateCart(userId);

    const itemIndex = cart.items.findIndex(
      (i) => i.productId.toString() === productId
    );

    if (itemIndex >= 0) {
      // Already exists → increase quantity
      cart.items[itemIndex].quantity += quantity;
    } else {
      // Add new product
      cart.items.push({ productId, quantity });
    }

    await cart.save();
    return cart;
  }

  // Update quantity
  static async updateQuantity(userId, productId, quantity) {
    const cart = await Cart.findOne({ userId });
    if (!cart) throw new Error("Cart not found");

    const item = cart.items.find(
      (i) => i.productId.toString() === productId
    );

    if (!item) throw new Error("Item not found");

    if (quantity <= 0) {
      // Remove item
      cart.items = cart.items.filter(
        (i) => i.productId.toString() !== productId
      );
    } else {
      item.quantity = quantity;
    }

    await cart.save();
    return cart;
  }

  // Remove item from cart
  static async removeItem(userId, productId) {
    const cart = await Cart.findOne({ userId });
    if (!cart) return cart;

    cart.items = cart.items.filter(
      (i) => i.productId.toString() !== productId
    );

    await cart.save();
    return cart;
  }

  // Clear cart
  static async clearCart(userId) {
    const cart = await Cart.findOne({ userId });
    if (!cart) return null;

    cart.items = [];
    await cart.save();
    return cart;
  }
}

module.exports = CartService;
