const Order = require("../models/Order");
const Product = require("../models/Product");
const InventoryService = require("./inventory.service");

class OrderService {

  // CREATE ORDER
  static async createOrder({ userId, items, address, paymentMethod }) {

    let total = 0;

    // Build items array with snapshot prices + ownerId
    const detailedItems = [];
    for (const it of items) {
      const product = await Product.findById(it.productId).lean();
      if (!product) throw new Error("Product not found");

      const amount = product.price * it.quantity;
      total += amount;

      detailedItems.push({
        productId: product._id,
        quantity: it.quantity,
        price: product.price,
        ownerId: product.ownerId
      });
    }

    // Reduce inventory for each product
    for (const it of detailedItems) {
      await InventoryService.updateQuantity({
        productId: it.productId,
        delta: -it.quantity,
        reason: "order_placed",
        refId: "ORDER_PENDING",
        userId
      });
    }

    const order = await Order.create({
      userId,
      items: detailedItems,
      totalAmount: total,
      status: paymentMethod === "COD" ? "pending" : "paid",
      address,
      paymentMethod
    });

    return order;
  }

  // GET USER ORDERS
  static async getUserOrders(userId) {
    return Order.find({ userId }).sort({ createdAt: -1 }).lean();
  }

  // GET ORDER (by ID)
  static async getOrder(orderId) {
    const order = await Order.findById(orderId).populate("userId", "email");
    if (!order) throw new Error("Order not found");
    return order;
  }

  // UPDATE ORDER STATUS
  static async updateStatus(orderId, status) {
    const order = await Order.findById(orderId);
    if (!order) throw new Error("Order not found");

    order.status = status;
    await order.save();

    return order;
  }

  // ASSIGN DELIVERY PARTNER
  static async assignDelivery(orderId, partnerId) {
    const order = await Order.findById(orderId);
    if (!order) throw new Error("Order not found");

    order.deliveryPartnerId = partnerId;
    order.status = "shipped";
    await order.save();

    return order;
  }
}

module.exports = OrderService;
