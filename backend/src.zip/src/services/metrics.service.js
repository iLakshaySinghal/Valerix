const InventoryItem = require("../models/InventoryItem");
const InventoryLog = require("../models/InventoryLog");
const Order = require("../models/Order"); // existing order model (assumed)
const Product = require("../models/Product");

/**
 * MetricsService
 * - compute useful KPIs for admin dashboard
 */
class MetricsService {

  // Basic inventory KPIs: total SKUs, out-of-stock, low-stock count
  static async inventoryKPIs() {
    const totalSKUs = await InventoryItem.countDocuments({});
    const outOfStock = await InventoryItem.countDocuments({ quantity: { $lte: 0 } });
    const lowStock = await InventoryItem.countDocuments({ $expr: { $lte: ["$quantity", "$reorderLevel"] } });

    return { totalSKUs, outOfStock, lowStock };
  }

  // Sales KPIs over a time range (default last 30 days)
  static async salesKPIs({ startDate, endDate } = {}) {
    // fallback to last 30 days
    const end = endDate ? new Date(endDate) : new Date();
    const start = startDate ? new Date(startDate) : new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);

    // Order model assumed to have items: [{ productId, quantity, price }]
    const orders = await Order.find({
      createdAt: { $gte: start, $lte: end },
      status: { $in: ["paid", "shipped", "delivered"] } // adjust statuses
    }).select("items totalAmount createdAt").lean();

    const totalOrders = orders.length;
    const totalRevenue = orders.reduce((s, o) => s + (o.totalAmount || 0), 0);

    // calculate top selling products
    const productMap = new Map();
    for (const o of orders) {
      for (const it of o.items || []) {
        const pid = it.productId.toString();
        const prev = productMap.get(pid) || 0;
        productMap.set(pid, prev + (it.quantity || 0));
      }
    }

    // convert to array and fetch product names
    const entries = Array.from(productMap.entries()).map(([pid, qty]) => ({ productId: pid, qty }));
    entries.sort((a, b) => b.qty - a.qty);
    const topN = entries.slice(0, 10);
    // fetch product names
    const pids = topN.map(t => t.productId);
    const products = await Product.find({ _id: { $in: pids } }).select("name").lean();
    const prodById = Object.fromEntries(products.map(p => [p._id.toString(), p]));
    const topSelling = topN.map(t => ({ productId: t.productId, qty: t.qty, name: (prodById[t.productId] && prodById[t.productId].name) || "Unknown" }));

    return { totalOrders, totalRevenue, topSelling, start, end };
  }

  // Simple traffic metrics placeholder: pageViews, uniqueVisitors — requires instrumentation/logging
  static async trafficKPIs({ startDate, endDate } = {}) {
    // For now return stub; wire to analytics logs or 3rd party later (Google Analytics/CloudWatch)
    return {
      pageViews: 0,
      uniqueVisitors: 0,
      avgSessionDuration: 0,
      startDate,
      endDate,
      note: "Traffic metrics not implemented server-side. Integrate analytics (GA4/segment) or collect events."
    };
  }

  // Combined admin dashboard payload
  static async dashboard({ startDate, endDate } = {}) {
    const inventory = await MetricsService.inventoryKPIs();
    const sales = await MetricsService.salesKPIs({ startDate, endDate });
    const traffic = await MetricsService.trafficKPIs({ startDate, endDate });

    return { inventory, sales, traffic };
  }
}

module.exports = MetricsService;
