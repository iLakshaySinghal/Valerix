const Product = require("../models/Product");
const Category = require("../models/Category");
const slugify = require("slugify");
const mongoose = require("mongoose");

class ProductService {
  /**
   * Create product (startup owner)
   * @param {String} startupId - ObjectId string of startup owner
   * @param {Object} payload - product fields
   */
  static async createProduct(startupId, payload) {
    // validate category if provided
    if (payload.category) {
      const catExists = await Category.findById(payload.category);
      if (!catExists) throw new Error("Category not found");
    }

    payload.startup = startupId;
    payload.slug = payload.slug || slugify(payload.name || "product", { lower: true, strict: true });

    // ensure slug uniqueness: append random suffix if exists
    let candidateSlug = payload.slug;
    let suffix = 0;
    while (await Product.findOne({ slug: candidateSlug })) {
      suffix++;
      candidateSlug = `${payload.slug}-${suffix}`;
    }
    payload.slug = candidateSlug;

    const p = await Product.create(payload);
    return p;
  }

  /**
   * Update product (owner or admin)
   * @param {String} productId
   * @param {String} requesterId
   * @param {Object} updates
   * @param {Object} options - { isAdmin: Boolean }
   */
  static async updateProduct(productId, requesterId, updates, options = {}) {
    if (!mongoose.Types.ObjectId.isValid(productId)) throw new Error("Invalid product id");

    const filter = { _id: productId, isDeleted: false };
    if (!options.isAdmin) {
      filter.startup = requesterId;
    }

    const product = await Product.findOne(filter);
    if (!product) throw new Error("Product not found or not authorized");

    if (updates.name && updates.name !== product.name) {
      updates.slug = slugify(updates.name, { lower: true, strict: true });
      // ensure slug unique
      let base = updates.slug;
      let candidate = base;
      let i = 0;
      while (await Product.findOne({ slug: candidate, _id: { $ne: productId } })) {
        i++;
        candidate = `${base}-${i}`;
      }
      updates.slug = candidate;
    }

    // validate category
    if (updates.category) {
      const cat = await Category.findById(updates.category);
      if (!cat) throw new Error("Category not found");
    }

    Object.assign(product, updates);
    await product.save();
    return product;
  }

  /**
   * Soft delete product (owner or admin)
   */
  static async softDelete(productId, requesterId, options = {}) {
    const filter = { _id: productId, isDeleted: false };
    if (!options.isAdmin) filter.startup = requesterId;

    const product = await Product.findOneAndUpdate(filter, { isDeleted: true }, { new: true });
    if (!product) throw new Error("Product not found or not authorized");
    return product;
  }

  /**
   * Get single product, populate category & startup, increment view count (non-blocking)
   */
  static async getProductById(productId) {
    if (!mongoose.Types.ObjectId.isValid(productId)) return null;
    const p = await Product.findById(productId)
      .populate("category", "name slug")
      .populate("startup", "name email role");
    if (!p || p.isDeleted) return null;

    // increment views in background
    Product.findByIdAndUpdate(productId, { $inc: { views: 1 } }).exec();
    return p;
  }

  /**
   * Listing with pagination, search, filters, sorting
   * query object accepts page, limit, q, category, minPrice, maxPrice, inStock, startup, sort
   */
  static async listProducts(query = {}) {
    const {
      page = 1,
      limit = 12,
      q,
      category,
      minPrice,
      maxPrice,
      sort = "createdAt:desc",
      inStock,
      startup,
    } = query;

    const filter = { isDeleted: false };

    if (category) {
      // allow category id or slug
      if (mongoose.Types.ObjectId.isValid(category)) filter.category = category;
      else {
        const cat = await Category.findOne({ slug: category });
        if (cat) filter.category = cat._id;
        else filter.category = null; // will return no items
      }
    }

    if (startup && mongoose.Types.ObjectId.isValid(startup)) filter.startup = startup;

    if (inStock !== undefined) {
      if (String(inStock) === "true") filter.stock = { $gt: 0 };
      if (String(inStock) === "false") filter.stock = { $lte: 0 };
    }

    if (minPrice !== undefined || maxPrice !== undefined) {
      filter.price = {};
      if (minPrice !== undefined) filter.price.$gte = Number(minPrice);
      if (maxPrice !== undefined) filter.price.$lte = Number(maxPrice);
    }

    if (q) {
      // text search first
      filter.$text = { $search: q };
    }

    // parse sort string "field:dir"
    let [field, dir] = sort.split(":");
    dir = dir === "asc" ? 1 : -1;
    const sortObj = {};
    // map some friendly keys
    if (field === "price") sortObj.price = dir;
    else if (field === "rating") sortObj.rating = dir;
    else if (field === "sales") sortObj.salesCount = dir;
    else if (field === "views") sortObj.views = dir;
    else if (field === "createdAt") sortObj.createdAt = dir;
    else sortObj.createdAt = -1;

    const skip = (Math.max(Number(page), 1) - 1) * Number(limit);

    const [items, total] = await Promise.all([
      Product.find(filter)
        .populate("category", "name slug")
        .populate("startup", "name email")
        .sort(sortObj)
        .skip(skip)
        .limit(Number(limit))
        .lean(),
      Product.countDocuments(filter)
    ]);

    const pages = Math.ceil(total / Number(limit) || 1);

    return {
      items,
      total,
      page: Number(page),
      pages,
      limit: Number(limit)
    };
  }
}

module.exports = ProductService;
