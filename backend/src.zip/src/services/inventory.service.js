const InventoryItem = require("../models/InventoryItem");
const InventoryLog = require("../models/InventoryLog");
const Product = require("../models/Product");

/**
 * InventoryService
 * - central place to update inventory and keep audit logs
 */
class InventoryService {

  // Ensure inventory item exists for product
  static async ensureInventoryForProduct(productId) {
    let item = await InventoryItem.findOne({ productId });
    if (!item) {
      item = await InventoryItem.create({ productId, quantity: 0 });
    }
    return item;
  }

  // Get inventory list with pagination and optional filters
  static async listInventory({ page = 1, limit = 20, q, lowStock = false }) {
    const filter = {};
    if (q) {
      // try to match SKU or product name (join)
      const products = await Product.find({ name: { $regex: q, $options: "i" } }).select("_id").lean();
      const pids = products.map(p => p._id);
      filter.$or = [{ sku: { $regex: q, $options: "i" } }, { productId: { $in: pids } }];
    }
    if (lowStock) {
      filter.$expr = { $lte: ["$quantity", "$reorderLevel"] };
    }

    const skip = (page - 1) * limit;
    const [items, total] = await Promise.all([
      InventoryItem.find(filter).sort({ updatedAt: -1 }).skip(skip).limit(Number(limit)).populate("productId", "name price").lean(),
      InventoryItem.countDocuments(filter)
    ]);

    return { items, total, page, pages: Math.ceil(total / limit) || 1 };
  }

  // Update quantity (delta can be positive or negative)
  static async updateQuantity({ productId, delta, reason = "manual_update", refId = "", userId = null }) {
    const item = await InventoryService.ensureInventoryForProduct(productId);

    const before = item.quantity;
    const after = before + Number(delta);

    if (after < 0) {
      throw Object.assign(new Error("Insufficient stock"), { status: 400 });
    }

    item.quantity = after;
    await item.save();

    const log = await InventoryLog.create({
      productId,
      change: delta,
      reason,
      refId,
      userId,
      beforeQuantity: before,
      afterQuantity: after
    });

    return { item, log };
  }

  // Set absolute quantity (overwrite)
  static async setQuantity({ productId, quantity, reason = "set_quantity", refId = "", userId = null }) {
    const item = await InventoryService.ensureInventoryForProduct(productId);

    const before = item.quantity;
    item.quantity = Number(quantity);
    await item.save();

    const log = await InventoryLog.create({
      productId,
      change: item.quantity - before,
      reason,
      refId,
      userId,
      beforeQuantity: before,
      afterQuantity: item.quantity
    });

    return { item, log };
  }

  // Get inventory item by productId
  static async getByProduct(productId) {
    return InventoryItem.findOne({ productId }).populate("productId", "name price").lean();
  }

  // Get logs for a product
  static async getLogs({ productId, page = 1, limit = 50 }) {
    const skip = (page - 1) * limit;
    const [items, total] = await Promise.all([
      InventoryLog.find({ productId }).sort({ createdAt: -1 }).skip(skip).limit(Number(limit)).lean(),
      InventoryLog.countDocuments({ productId })
    ]);
    return { items, total, page, pages: Math.ceil(total / limit) || 1 };
  }

}

module.exports = InventoryService;
