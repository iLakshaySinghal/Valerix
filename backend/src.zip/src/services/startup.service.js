const StartupProfile = require("../models/StartupProfile");

class StartupService {

  // CREATE or UPDATE startup profile
  static async upsertStartupProfile(ownerId, data) {
    let profile = await StartupProfile.findOne({ ownerId });

    if (!profile) {
      profile = await StartupProfile.create({
        ownerId,
        ...data
      });
    } else {
      Object.assign(profile, data);
      await profile.save();
    }

    return profile;
  }

  // GET startup profile by user ID
  static async getStartupProfile(ownerId) {
    const profile = await StartupProfile.findOne({ ownerId });
    if (!profile) throw new Error("Startup profile not found");
    return profile;
  }

  // DISCOVER startups (like a feed)
  static async discoverStartups(query) {
    const {
      q,
      industry,
      location,
      page = 1,
      limit = 10
    } = query;

    const filter = {};

    if (industry) filter.industry = industry;
    if (location) filter.location = location;

    if (q) {
      filter.$or = [
        { startupName: { $regex: q, $options: "i" } },
        { description: { $regex: q, $options: "i" } }
      ];
    }

    const skip = (page - 1) * limit;

    const [items, total] = await Promise.all([
      StartupProfile.find(filter).skip(skip).limit(Number(limit)).lean(),
      StartupProfile.countDocuments(filter)
    ]);

    return {
      items,
      total,
      page,
      pages: Math.ceil(total / limit)
    };
  }

  // ADD collaborator (bidirectional)
  static async addCollaborator(ownerId, targetId) {
    const userProfile = await StartupProfile.findOne({ ownerId });
    const targetProfile = await StartupProfile.findOne({ ownerId: targetId });

    if (!userProfile || !targetProfile) {
      throw new Error("One or both startup profiles not found");
    }

    // Prevent duplicates
    if (!userProfile.collaborators.includes(targetProfile._id)) {
      userProfile.collaborators.push(targetProfile._id);
      await userProfile.save();
    }

    if (!targetProfile.collaborators.includes(userProfile._id)) {
      targetProfile.collaborators.push(userProfile._id);
      await targetProfile.save();
    }

    return { message: "Collaboration connected" };
  }
}

module.exports = StartupService;
