const mongoose = require("mongoose");

const ProductSchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true },
  slug: { type: String, required: true, unique: true, lowercase: true, trim: true },
  description: { type: String },
  price: { type: Number, required: true },
  currency: { type: String, default: "INR" },
  stock: { type: Number, default: 0 },
  images: [{ url: String, alt: String }],           // store S3 URLs or local
  category: { type: mongoose.Schema.Types.ObjectId, ref: "Category", index: true },
  startup: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true, index: true },
  isDeleted: { type: Boolean, default: false },
  views: { type: Number, default: 0 },
  salesCount: { type: Number, default: 0 },
  rating: { type: Number, default: 0 },
  reviewCount: { type: Number, default: 0 },
}, { timestamps: true });

// text index for search
ProductSchema.index({ name: "text", description: "text" });

module.exports = mongoose.model("Product", ProductSchema);
