const mongoose = require("mongoose");

const StartupProfileSchema = new mongoose.Schema(
  {
    ownerId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
      unique: true
    },

    startupName: {
      type: String,
      required: true,
      trim: true
    },

    description: {
      type: String,
      default: ""
    },

    logo: {
      type: String, // S3 URL
      default: ""
    },

    tags: {
      type: [String],
      default: []
    },

    // For collaboration suggestions
    industry: {
      type: String,
      required: true
    },

    location: {
      type: String,
      default: ""
    },

    // People they collaborated with
    collaborators: [{
      type: mongoose.Schema.Types.ObjectId,
      ref: "StartupProfile"
    }],

  },
  { timestamps: true }
);

module.exports = mongoose.model("StartupProfile", StartupProfileSchema);
