const router = require("express").Router();
const authJwt = require("../middlewares/authJwt");
const requireRole = require("../middlewares/requireRole");
const orderController = require("../controllers/order.controller");

// All order routes need login
router.use(authJwt);

// User creates order
router.post("/", requireRole(["user"]), orderController.createOrder);

// Get all orders for logged-in user
router.get("/", requireRole(["user"]), orderController.getUserOrders);

// Get single order
router.get("/:id", orderController.getOrder);

// Admin updates order status
router.put("/:id/status", requireRole(["admin"]), orderController.updateStatus);

// Admin assigns delivery partner
router.post("/:id/assign", requireRole(["admin"]), orderController.assignDelivery);

module.exports = router;
