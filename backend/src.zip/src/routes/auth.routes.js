const router = require("express").Router();
const { requestOTP, verifyOTP } = require("../controllers/auth.controller");
const { authLimiter } = require("../middlewares/rateLimiter");
const { auth } = require("../middlewares/auth.middleware");

// Public routes
router.post("/request-otp", authLimiter, requestOTP);
router.post("/verify-otp", verifyOTP);

// Protected route → requires JWT
router.get("/me", auth, (req, res) => {
  res.json({
    success: true,
    user: req.user,
  });
});

module.exports = router;
