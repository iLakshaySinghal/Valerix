const router = require("express").Router();
const {
  createProduct,
  getProduct,
  updateProduct,
  deleteProduct,
  listProducts,
} = require("../controllers/product.controller");

// NOTE: adapt these requires to your project's actual filenames
// the user used `authJwt` and `requireRole` earlier — keep the same names if those files exist
const authJwt = require("../middlewares/authJwt") || require("../middlewares/auth.middleware");
const requireRole = require("../middlewares/requireRole");

// Public routes
router.get("/", listProducts);
router.get("/:id", getProduct);

// Protected routes: startup owners or admins
router.post("/", authJwt, requireRole(["startup", "admin"]), createProduct);
router.put("/:id", authJwt, requireRole(["startup", "admin"]), updateProduct);
router.delete("/:id", authJwt, requireRole(["startup", "admin"]), deleteProduct);

module.exports = router;
