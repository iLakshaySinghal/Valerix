const router = require("express").Router();
const authJwt = require("../middlewares/authJwt");

const {
  getCart,
  addToCart,
  updateQuantity,
  removeItem,
  clearCart
} = require("../controllers/cart.controller");

router.use(authJwt);

// Get user cart
router.get("/", getCart);

// Add item
router.post("/", addToCart);

// Update quantity
router.put("/", updateQuantity);

// Remove item
router.delete("/:productId", removeItem);

// Clear cart
router.delete("/", clearCart);

module.exports = router;
