const router = require("express").Router();
const authJwt = require("../middlewares/authJwt");

const {
  addAddress,
  updateAddress,
  deleteAddress,
  setDefaultAddress
} = require("../controllers/address.controller");

router.post("/", authJwt, addAddress);
router.put("/:id", authJwt, updateAddress);
router.delete("/:id", authJwt, deleteAddress);
router.patch("/default/:id", authJwt, setDefaultAddress);

module.exports = router;
