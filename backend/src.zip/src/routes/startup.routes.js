const router = require("express").Router();
const authJwt = require("../middlewares/authJwt");
const requireRole = require("../middlewares/requireRole");

const {
  upsertProfile,
  getProfile,
  discover,
  addCollaborator
} = require("../controllers/startup.controller");

// Only startup owners can manage profiles
router.use(authJwt);

// Create or update profile
router.post("/profile", requireRole(["startup"]), upsertProfile);

// Get profile of current startup
router.get("/profile", requireRole(["startup"]), getProfile);

// Discover other startups
router.get("/discover", requireRole(["startup"]), discover);

// Add collaborator
router.post("/collaborate", requireRole(["startup"]), addCollaborator);

module.exports = router;
