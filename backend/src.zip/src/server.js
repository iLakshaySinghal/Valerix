const http = require("http");
const { createServer } = require("http");
const app = require("./app");
const connectDB = require("./config/db");
const logger = require("./utils/logger");
const socketInit = require("./sockets"); // we'll create sockets/index.js later
require("dotenv").config();

const PORT = process.env.PORT || 5000;

// connect to DB
connectDB()
  .then(() => {
    const server = createServer(app);

    // initialize sockets (pass http server)
    socketInit(server);

    server.listen(PORT, () => {
      logger.info(`Server running in ${process.env.NODE_ENV} on port ${PORT}`);
      console.log(`Server running on http://localhost:${PORT}`);
    });
  })
  .catch((err) => {
    console.error("Failed to start server:", err);
    process.exit(1);
  });
