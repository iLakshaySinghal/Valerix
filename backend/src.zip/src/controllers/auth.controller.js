const AuthService = require("../services/auth.service");

exports.requestOTP = async (req, res, next) => {
  try {
    const { email, phone, role } = req.body;

    // If user is logged in → get their role
    const requesterRole = req.user?.role || "user";

    const data = await AuthService.requestOTP(
      email,
      phone,
      role,
      requesterRole
    );

    res.json(data);

  } catch (err) {
    next(err);
  }
};

exports.verifyOTP = async (req, res, next) => {
  try {
    const { email, otp } = req.body;

    const data = await AuthService.verifyOTP(email, otp);

    res.json(data);

  } catch (err) {
    next(err);
  }
};
