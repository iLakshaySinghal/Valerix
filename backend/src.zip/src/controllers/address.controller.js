const Address = require("../models/Address");

exports.addAddress = async (req, res, next) => {
  try {
    const data = { ...req.body, user: req.user.id };

    // If first address → set as default
    const count = await Address.countDocuments({ user: req.user.id });
    if (count === 0) data.isDefault = true;

    const address = await Address.create(data);

    res.json({ success: true, address });
  } catch (err) {
    next(err);
  }
};

exports.updateAddress = async (req, res, next) => {
  try {
    const address = await Address.findOneAndUpdate(
      { _id: req.params.id, user: req.user.id },
      req.body,
      { new: true }
    );

    if (!address) throw new Error("Address not found");

    res.json({ success: true, address });
  } catch (err) {
    next(err);
  }
};

exports.deleteAddress = async (req, res, next) => {
  try {
    const deleted = await Address.findOneAndDelete({
      _id: req.params.id,
      user: req.user.id
    });

    if (!deleted) throw new Error("Address not found");

    res.json({ success: true, message: "Address removed" });
  } catch (err) {
    next(err);
  }
};

exports.setDefaultAddress = async (req, res, next) => {
  try {
    const id = req.params.id;

    const address = await Address.findOne({ _id: id, user: req.user.id });
    if (!address) throw new Error("Address not found");

    // Remove default from all
    await Address.updateMany(
      { user: req.user.id },
      { $set: { isDefault: false } }
    );

    // Set this one as default
    address.isDefault = true;
    await address.save();

    res.json({ success: true, message: "Default address updated" });
  } catch (err) {
    next(err);
  }
};
