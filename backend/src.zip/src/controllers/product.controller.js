const ProductService = require("../services/product.service");

/**
 * Create product (startup owner)
 * - req.user should contain { id, role }
 */
exports.createProduct = async (req, res, next) => {
  try {
    const ownerId = req.user.id;
    const product = await ProductService.createProduct(ownerId, req.body);
    res.status(201).json({ success: true, product });
  } catch (err) {
    next(err);
  }
};

exports.getProduct = async (req, res, next) => {
  try {
    const product = await ProductService.getProductById(req.params.id);
    if (!product) return res.status(404).json({ success: false, message: "Product not found" });
    res.json({ success: true, product });
  } catch (err) {
    next(err);
  }
};

exports.updateProduct = async (req, res, next) => {
  try {
    const requesterId = req.user.id;
    const isAdmin = req.user.role === "admin";
    const product = await ProductService.updateProduct(req.params.id, requesterId, req.body, { isAdmin });
    res.json({ success: true, product });
  } catch (err) {
    next(err);
  }
};

exports.deleteProduct = async (req, res, next) => {
  try {
    const requesterId = req.user.id;
    const isAdmin = req.user.role === "admin";
    const product = await ProductService.softDelete(req.params.id, requesterId, { isAdmin });
    res.json({ success: true, message: "Product deleted", product });
  } catch (err) {
    next(err);
  }
};

exports.listProducts = async (req, res, next) => {
  try {
    const data = await ProductService.listProducts(req.query);
    res.json({ success: true, ...data });
  } catch (err) {
    next(err);
  }
};
