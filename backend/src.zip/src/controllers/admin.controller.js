const InventoryService = require("../services/inventory.service");
const MetricsService = require("../services/metrics.service");

exports.getInventory = async (req, res, next) => {
  try {
    const query = req.query;
    const data = await InventoryService.listInventory(query);
    res.json({ success: true, ...data });
  } catch (err) {
    next(err);
  }
};

exports.updateStock = async (req, res, next) => {
  try {
    const { productId, delta, reason, refId } = req.body;
    if (!productId || typeof delta === "undefined") {
      const e = new Error("productId and delta are required");
      e.status = 400;
      throw e;
    }
    const userId = req.user ? req.user.id : null;
    const result = await InventoryService.updateQuantity({ productId, delta: Number(delta), reason, refId, userId });
    res.json({ success: true, ...result });
  } catch (err) {
    next(err);
  }
};

exports.setStock = async (req, res, next) => {
  try {
    const { productId, quantity, reason, refId } = req.body;
    if (!productId || typeof quantity === "undefined") {
      const e = new Error("productId and quantity are required");
      e.status = 400;
      throw e;
    }
    const userId = req.user ? req.user.id : null;
    const result = await InventoryService.setQuantity({ productId, quantity: Number(quantity), reason, refId, userId });
    res.json({ success: true, ...result });
  } catch (err) {
    next(err);
  }
};

exports.getLogs = async (req, res, next) => {
  try {
    const { productId } = req.params;
    const { page = 1, limit = 50 } = req.query;
    const data = await InventoryService.getLogs({ productId, page, limit });
    res.json({ success: true, ...data });
  } catch (err) {
    next(err);
  }
};

exports.getDashboard = async (req, res, next) => {
  try {
    const { startDate, endDate } = req.query;
    const data = await MetricsService.dashboard({ startDate, endDate });
    res.json({ success: true, ...data });
  } catch (err) {
    next(err);
  }
};
