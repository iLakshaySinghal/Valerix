const StartupService = require("../services/startup.service");

exports.upsertProfile = async (req, res, next) => {
  try {
    const ownerId = req.user.id; // from JWT middleware
    const data = req.body;

    const profile = await StartupService.upsertStartupProfile(ownerId, data);

    res.json({
      success: true,
      profile
    });
  } catch (err) {
    next(err);
  }
};

exports.getProfile = async (req, res, next) => {
  try {
    const ownerId = req.user.id;

    const profile = await StartupService.getStartupProfile(ownerId);

    res.json({
      success: true,
      profile
    });
  } catch (err) {
    next(err);
  }
};

exports.discover = async (req, res, next) => {
  try {
    const data = await StartupService.discoverStartups(req.query);

    res.json({
      success: true,
      ...data
    });
  } catch (err) {
    next(err);
  }
};

exports.addCollaborator = async (req, res, next) => {
  try {
    const ownerId = req.user.id;
    const { targetId } = req.body;

    const result = await StartupService.addCollaborator(ownerId, targetId);

    res.json({
      success: true,
      ...result
    });
  } catch (err) {
    next(err);
  }
};
