const OrderService = require("../services/order.service");

exports.createOrder = async (req, res, next) => {
  try {
    const userId = req.user.id;
    const { items, address, paymentMethod } = req.body;

    const order = await OrderService.createOrder({
      userId,
      items,
      address,
      paymentMethod
    });

    res.status(201).json({ success: true, order });

  } catch (err) {
    next(err);
  }
};

exports.getUserOrders = async (req, res, next) => {
  try {
    const userId = req.user.id;
    const orders = await OrderService.getUserOrders(userId);
    res.json({ success: true, orders });
  } catch (err) {
    next(err);
  }
};

exports.getOrder = async (req, res, next) => {
  try {
    const order = await OrderService.getOrder(req.params.id);
    res.json({ success: true, order });
  } catch (err) {
    next(err);
  }
};

exports.updateStatus = async (req, res, next) => {
  try {
    const order = await OrderService.updateStatus(req.params.id, req.body.status);
    res.json({ success: true, order });
  } catch (err) {
    next(err);
  }
};

exports.assignDelivery = async (req, res, next) => {
  try {
    const { partnerId } = req.body;
    const order = await OrderService.assignDelivery(req.params.id, partnerId);
    res.json({ success: true, order });
  } catch (err) {
    next(err);
  }
};
