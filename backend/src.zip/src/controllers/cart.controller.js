const CartService = require("../services/cart.service");

exports.getCart = async (req, res, next) => {
  try {
    const cart = await CartService.getCart(req.user.id);
    res.json({ success: true, cart });
  } catch (err) {
    next(err);
  }
};

exports.addToCart = async (req, res, next) => {
  try {
    const userId = req.user.id;
    const { productId, quantity } = req.body;

    const cart = await CartService.addToCart(userId, productId, Number(quantity));
    res.json({ success: true, cart });
  } catch (err) {
    next(err);
  }
};

exports.updateQuantity = async (req, res, next) => {
  try {
    const userId = req.user.id;
    const { productId, quantity } = req.body;

    const cart = await CartService.updateQuantity(
      userId,
      productId,
      Number(quantity)
    );

    res.json({ success: true, cart });
  } catch (err) {
    next(err);
  }
};

exports.removeItem = async (req, res, next) => {
  try {
    const userId = req.user.id;
    const { productId } = req.params;

    const cart = await CartService.removeItem(userId, productId);
    res.json({ success: true, cart });
  } catch (err) {
    next(err);
  }
};

exports.clearCart = async (req, res, next) => {
  try {
    const cart = await CartService.clearCart(req.user.id);
    res.json({ success: true, cart });
  } catch (err) {
    next(err);
  }
};
