import React, { useEffect, useState } from "react";
import api from "../utils/api";
import ProductCard from "../components/ProductCard";
import NeonLoader from "../components/ui/NeonLoader";

export default function ProductList({ compact }) {
  const [loading, setLoading] = useState(false);
  const [items, setItems] = useState([]);
  const [page, setPage] = useState(1);
  const [q, setQ] = useState("");

  useEffect(() => { fetchProducts(); }, [page]);

  async function fetchProducts() {
    setLoading(true);
    try {
      const res = await api.get("/products", { params: { page } });
      setItems(res.data.items || res.data);
    } catch (err) {
      console.error(err);
    } finally { setLoading(false); }
  }

  const list = q ? items.filter(p => p.name?.toLowerCase().includes(q.toLowerCase())) : items;

  return (
    <div>
      <div className="flex gap-3 items-center mb-4">
        <input placeholder="Search..." value={q} onChange={(e)=>setQ(e.target.value)} className="flex-1 p-2 bg-zinc-800 rounded" />
      </div>

      {loading ? <NeonLoader /> : (
        <div className={`grid ${compact ? "grid-cols-2 sm:grid-cols-4" : "grid-cols-1 sm:grid-cols-3"} gap-4`}>
          {list.map((p)=> <ProductCard key={p._id||p.id} product={p} />)}
        </div>
      )}
    </div>
  );
}
