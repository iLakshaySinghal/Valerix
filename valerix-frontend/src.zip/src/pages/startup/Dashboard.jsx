import DashboardLayout from "../../components/dashboard/Layout.jsx";
import ProductsCRUD from "./ProductsCRUD.jsx";

export default function Dashboard() {
  return (
    <DashboardLayout>
      <ProductsCRUD />
    </DashboardLayout>
  );
}
