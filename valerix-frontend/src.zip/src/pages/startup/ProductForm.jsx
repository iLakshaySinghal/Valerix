import React, { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import api from "../../utils/api";
import NeonLoader from "../../components/ui/NeonLoader";

export default function ProductForm(){
  const { id } = useParams();
  const [loading,setLoading] = useState(false);
  const [product,setProduct] = useState({ name:"", description:"", price:0, stock:0, images:[] , category:"" });
  const nav = useNavigate();

  useEffect(()=>{ if(id) load(); }, [id]);

  async function load(){
    setLoading(true);
    try {
      const res = await api.get(`/products/${id}`);
      setProduct(res.data.product || res.data);
    } catch(e){ console.error(e); } finally { setLoading(false); }
  }

  async function onSave(e){
    e.preventDefault();
    setLoading(true);
    try {
      if (id) {
        await api.put(`/products/${id}`, product);
      } else {
        await api.post("/products", product);
      }
      nav("/startup/products");
    } catch (err) {
      alert(err?.response?.data?.message || err.message);
    } finally { setLoading(false); }
  }

  function addImage(){
    const url = prompt("Image URL");
    if (!url) return;
    setProduct(prev => ({ ...prev, images: [...(prev.images||[]), { url }] }));
  }

  return (
    <div className="max-w-3xl mx-auto bg-[#0b0b0d] p-6 rounded border border-zinc-800">
      <h2 className="text-2xl text-neon mb-4">{id ? "Edit Product" : "Create Product"}</h2>
      {loading ? <NeonLoader/> : (
        <form onSubmit={onSave} className="space-y-3">
          <input required value={product.name} onChange={e=>setProduct({...product, name:e.target.value})} className="w-full p-2 bg-[#0f0f11] rounded" placeholder="Name" />
          <textarea value={product.description} onChange={e=>setProduct({...product, description:e.target.value})} className="w-full p-2 bg-[#0f0f11] rounded" placeholder="Description" />
          <div className="grid grid-cols-2 gap-3">
            <input type="number" value={product.price} onChange={e=>setProduct({...product, price:Number(e.target.value)})} className="p-2 bg-[#0f0f11] rounded" placeholder="Price" />
            <input type="number" value={product.stock} onChange={e=>setProduct({...product, stock:Number(e.target.value)})} className="p-2 bg-[#0f0f11] rounded" placeholder="Stock" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <button type="button" onClick={addImage} className="px-3 py-1 bg-zinc-800 rounded">Add Image</button>
              <span className="text-sm text-zinc-400">Images: {(product.images||[]).length}</span>
            </div>
            <div className="mt-2 flex gap-2">
              {(product.images||[]).map((img,i)=> <img key={i} src={img.url} alt={`img-${i}`} className="w-20 h-20 object-cover rounded" />)}
            </div>
          </div>
          <div className="flex justify-end">
            <button type="submit" className="px-4 py-2 bg-neon rounded">Save</button>
          </div>
        </form>
      )}
    </div>
  );
}
