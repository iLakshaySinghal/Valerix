import React, { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import api from "../../utils/api";
import NeonLoader from "../../components/ui/NeonLoader";

export default function StartupProducts() {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const nav = useNavigate();

  useEffect(() => {
    load();
  }, []);

  async function load() {
    setLoading(true);
    try {
      // Fetch only logged-in startup's products
      const res = await api.get("/products?owner=true");
      setProducts(res.data.items || res.data);
    } catch (e) {
      console.error("Failed to load products", e);
    }
    setLoading(false);
  }

  async function remove(id) {
    if (!confirm("Delete this product?")) return;

    try {
      await api.delete(`/products/${id}`);
      load(); // refresh list
    } catch (err) {
      alert(err?.response?.data?.message || "Failed to delete product");
    }
  }

  if (loading) return <NeonLoader />;

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl text-neon">My Products</h2>
        <Link
          to="/startup/products/create"
          className="px-4 py-2 bg-neon rounded"
        >
          + Add Product
        </Link>
      </div>

      {products.length === 0 ? (
        <div className="text-zinc-400">
          No products added yet. Click{" "}
          <Link className="text-neon" to="/startup/products/create">
            here
          </Link>{" "}
          to create your first product.
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {products.map((p) => (
            <div
              key={p._id}
              className="bg-[#0f0f11] border border-zinc-800 rounded p-4"
            >
              <img
                src={
                  p.images?.[0]?.url ||
                  "/mnt/data/06787b30-a3dd-4dff-a854-ffa3134458d7.png"
                }
                alt={p.name}
                className="w-full h-40 object-cover rounded"
              />

              <h3 className="mt-3 font-semibold">{p.name}</h3>
              <div className="text-sm text-zinc-400">
                ₹{p.price} • Stock: {p.stock}
              </div>

              <div className="mt-4 flex justify-between">
                <button
                  onClick={() => nav(`/startup/products/${p._id}/edit`)}
                  className="px-3 py-1 bg-zinc-800 rounded"
                >
                  Edit
                </button>

                <button
                  onClick={() => remove(p._id)}
                  className="px-3 py-1 bg-red-500/40 border border-red-500 rounded"
                >
                  Delete
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
