import React, { useState } from "react";
import api from "../../utils/api";
import { useNavigate } from "react-router-dom";
import { useAuthStore } from "../../store/useAuthStore";

export default function VerifyOTP() {
  const [email, setEmail] = useState("");
  const [otp, setOtp] = useState("");
  const login = useAuthStore((s) => s.login);
  const navigate = useNavigate();

  async function submit() {
    try {
      const res = await api.post("/auth/verify-otp", { email, otp });

      // Save login state
      login(res.data.user, res.data.token);

      alert("Login Successful!");
      navigate("/home");

    } catch (err) {
      console.error(err);
      alert(err.response?.data?.message || "Invalid OTP");
    }
  }

  return (
    <div className="p-6 max-w-md mx-auto">
      <h1 className="text-2xl mb-4">Verify OTP</h1>

      <input
        placeholder="Email"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        className="w-full p-3 mb-3 rounded bg-[#0f0f11]"
      />

      <input
        placeholder="OTP"
        value={otp}
        onChange={(e) => setOtp(e.target.value)}
        className="w-full p-3 mb-3 rounded bg-[#0f0f11]"
      />

      <button onClick={submit} className="w-full p-3 bg-neon rounded">
        Verify
      </button>
    </div>
  );
}
