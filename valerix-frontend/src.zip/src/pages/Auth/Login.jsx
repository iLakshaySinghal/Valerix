import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { requestOtp } from "../../api/auth.js";

export default function Login() {
  const [phone, setPhone] = useState("");
  const [loading, setLoading] = useState(false);
  const nav = useNavigate();

  const submit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await requestOtp(phone);
      nav(`/verify?phone=${encodeURIComponent(phone)}`);
    } catch (err) {
      alert("Failed to request OTP");
    } finally {
      setLoading(false);
    }
  };

  return (
    <main className="max-w-md mx-auto mt-20 p-6 bg-[rgba(6,16,23,0.8)] rounded-2xl">
      <h2 className="text-2xl font-bold" style={{ color: "var(--accent)" }}>Login — OTP</h2>
      <form onSubmit={submit} className="mt-4">
        <label>Phone</label>
        <input value={phone} onChange={(e) => setPhone(e.target.value)} className="w-full p-2 rounded bg-[rgba(7,16,24,0.4)] mt-2" placeholder="+911234567890" />
        <button disabled={loading} className="w-full mt-4 p-2 rounded bg-[var(--accent)] text-black">Request OTP</button>
      </form>
    </main>
  );
}
