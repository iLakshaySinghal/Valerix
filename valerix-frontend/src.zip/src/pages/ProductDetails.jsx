import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import api from "../utils/api";
import NeonLoader from "../components/ui/NeonLoader";

export default function ProductDetails(){
  const { id } = useParams();
  const [product, setProduct] = useState(null);
  const [loading,setLoading] = useState(true);

  useEffect(()=>{ if(id) load(); }, [id]);

  async function load(){
    setLoading(true);
    try {
      const res = await api.get(`/products/${id}`);
      setProduct(res.data.product || res.data);
    } catch(e){ console.error(e); }
    setLoading(false);
  }

  if(loading) return <NeonLoader />;
  if(!product) return <div className="p-6">Product not found</div>;

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      <div className="col-span-1">
        <img src={product.images?.[0]?.url || "/src/assets/valerix-logo.png"} alt={product.name} className="w-full h-96 object-cover rounded" />
      </div>
      <div className="col-span-2">
        <h1 className="text-3xl font-bold text-neon">{product.name}</h1>
        <p className="mt-2 text-zinc-400">{product.description}</p>
        <div className="mt-4 font-semibold">₹{product.price}</div>
      </div>
    </div>
  );
}
