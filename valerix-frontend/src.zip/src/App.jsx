import React, { useEffect } from "react";
import { Routes, Route, Navigate } from "react-router-dom";

import Home from "./pages/Home";
import ProductList from "./pages/ProductList";
import ProductDetails from "./pages/ProductDetails";
import Cart from "./pages/Cart";
import Checkout from "./pages/Checkout";
import Addresses from "./pages/Addresses";
import Orders from "./pages/Orders";

import StartupProducts from "./pages/startup/Products";
import ProductForm from "./pages/startup/ProductForm";

import AdminCategories from "./pages/Admin/Categories";

import ChatPage from "./pages/Chat/ChatPage";

import RequestOTP from "./pages/Auth/RequestOTP";
import VerifyOTP from "./pages/Auth/VerifyOTP";

import Navbar from "./components/Navbar";
import MobileNav from "./components/MobileNav";

import { useAuthStore } from "./store/useAuthStore";

// ----------- Protected Route Wrapper ------------
function RequireAuth({ children, roles }) {
  const { user } = useAuthStore();

  if (!user) return <Navigate to="/auth/request-otp" replace />;

  if (roles && !roles.includes(user.role)) {
    return <div className="p-6">Access Denied</div>;
  }

  return children;
}

// ------------------------------------------------

export default function App() {
  const { initFromLocal } = useAuthStore();

  useEffect(() => {
    initFromLocal();
  }, []);

  return (
    <div className="min-h-screen bg-[var(--bg)] text-white">
      <Navbar />
      <MobileNav />

      <main className="container py-6">
        <Routes>

          {/* Redirect root */}
          <Route path="/" element={<Navigate to="/home" replace />} />

          {/* Public pages */}
          <Route path="/home" element={<Home />} />
          <Route path="/products" element={<ProductList />} />
          <Route path="/product/:id" element={<ProductDetails />} />

          {/* Cart & Checkout */}
          <Route path="/cart" element={<Cart />} />
          <Route
            path="/checkout"
            element={
              <RequireAuth>
                <Checkout />
              </RequireAuth>
            }
          />

          {/* Auth */}
          <Route path="/auth/request-otp" element={<RequestOTP />} />
          <Route path="/auth/verify-otp" element={<VerifyOTP />} />

          {/* -------- User Dashboard Features -------- */}
          <Route
            path="/addresses"
            element={
              <RequireAuth>
                <Addresses />
              </RequireAuth>
            }
          />

          <Route
            path="/orders"
            element={
              <RequireAuth>
                <Orders />
              </RequireAuth>
            }
          />

          {/* -------- Chat (User & Startup) -------- */}
          <Route
            path="/chat"
            element={
              <RequireAuth>
                <ChatPage />
              </RequireAuth>
            }
          />

          <Route
            path="/chat/:chatId"
            element={
              <RequireAuth>
                <ChatPage />
              </RequireAuth>
            }
          />

          {/* -------- Startup Dashboard -------- */}
          <Route
            path="/startup/products"
            element={
              <RequireAuth roles={["startup", "admin"]}>
                <StartupProducts />
              </RequireAuth>
            }
          />

          <Route
            path="/startup/products/create"
            element={
              <RequireAuth roles={["startup", "admin"]}>
                <ProductForm />
              </RequireAuth>
            }
          />

          <Route
            path="/startup/products/:id/edit"
            element={
              <RequireAuth roles={["startup", "admin"]}>
                <ProductForm />
              </RequireAuth>
            }
          />

          {/* -------- Admin Dashboard -------- */}
          <Route
            path="/admin/categories"
            element={
              <RequireAuth roles={["admin"]}>
                <AdminCategories />
              </RequireAuth>
            }
          />

          {/* 404 */}
          <Route path="*" element={<div className="p-6">404 Not Found</div>} />

        </Routes>
      </main>
    </div>
  );
}
