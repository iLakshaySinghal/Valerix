import React, { useEffect, useRef, useState } from "react";
import api from "../../utils/api";
import useSocket from "../../hooks/useSocket.js";


export default function ChatWindow({ chatId }) {
  const [messages, setMessages] = useState([]);
  const [text, setText] = useState("");
  const socketRef = useSocket(localStorage.getItem("token"));
  const boxRef = useRef();

  useEffect(()=>{
    fetchMessages();
    const s = socketRef.current;
    if (!s) return;
    const onMsg = (m) => {
      if (m.chatId === chatId) setMessages(prev => [...prev, m]);
    };
    s.on("message", onMsg);
    return () => { s.off("message", onMsg); };
  }, [chatId, socketRef.current]);

  async function fetchMessages(){
    try {
      const res = await api.get(`/chat/${chatId}/messages`);
      setMessages(res.data.items || res.data);
      setTimeout(()=>boxRef.current?.scrollTo(0, boxRef.current.scrollHeight), 100);
    } catch (e) { console.error(e); }
  }

  function send(){
    if (!text.trim()) return;
    const s = socketRef.current;
    // send via socket for real-time
    s.emit("send_message", { chatId, text, receiverId: null }); // server will infer receiver
    setText("");
  }

  return (
    <div className="flex flex-col h-96 border border-zinc-800 rounded bg-[#0b0b0d]">
      <div ref={boxRef} className="flex-1 overflow-auto p-4 space-y-3">
        {messages.map(m => (
          <div key={m._id} className={`p-2 rounded ${m.sender === (JSON.parse(localStorage.getItem("user"))?.id) ? "bg-neon/20 self-end" : "bg-zinc-800"}`}>
            <div className="text-sm">{m.text}</div>
            <div className="text-xs text-zinc-400 mt-1">{new Date(m.createdAt).toLocaleString()}</div>
          </div>
        ))}
      </div>
      <div className="p-3 border-t border-zinc-800 flex gap-2">
        <input value={text} onChange={(e)=>setText(e.target.value)} className="flex-1 p-2 rounded bg-[#0f0f11]" placeholder="Type a message..." />
        <button onClick={send} className="px-3 py-2 bg-neon rounded">Send</button>
      </div>
    </div>
  );
}
