import React, { useEffect, useState } from "react";
import api from "../../utils/api";
import { Link } from "react-router-dom";

export default function ChatList({ startupMode }) {
  // if startupMode, call /api/chat/conversations else fetch chats for user via /api/chat/my
  const [list, setList] = useState([]);

  useEffect(()=>{ load(); }, []);

  async function load(){
    try {
      const res = await api.get(startupMode ? "/chat/conversations" : "/chat/my");
      setList(res.data.items || res.data.chats || []);
    } catch (e) { console.error(e); }
  }

  return (
    <div className="space-y-2">
      {list.map(c => (
        <Link key={c._id} to={`/chat/${c._id}`} className="block p-3 bg-[#0f0f11] rounded border border-zinc-800">
          <div className="flex justify-between">
            <div className="font-medium">Conversation</div>
            <div className="text-sm text-zinc-400">{new Date(c.updatedAt||c.lastMessageAt).toLocaleString()}</div>
          </div>
        </Link>
      ))}
    </div>
  );
}
