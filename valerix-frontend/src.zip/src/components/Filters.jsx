import React from "react";

export default function Filters({ onChange }) {
  return (
    <aside className="w-64 p-4 bg-[rgba(6,16,23,0.6)] rounded-xl">
      <label className="block mb-2 text-sm">Search</label>
      <input
        onChange={(e) => onChange({ q: e.target.value })}
        placeholder="Search products..."
        className="w-full p-2 rounded bg-[rgba(7,16,24,0.4)]"
      />

      <div className="mt-4">
        <label className="block mb-1 text-sm">Category</label>
        <select
          onChange={(e) => onChange({ category: e.target.value })}
          className="w-full p-2 rounded bg-[rgba(7,16,24,0.4)]"
        >
          <option value="">All</option>
          <option value="tech">Tech</option>
          <option value="health">Health</option>
          <option value="home">Home</option>
        </select>
      </div>

      <div className="mt-4">
        <label className="block mb-1 text-sm">Sort</label>
        <select onChange={(e) => onChange({ sort: e.target.value })} className="w-full p-2 rounded bg-[rgba(7,16,24,0.4)]">
          <option value="">Recommended</option>
          <option value="price_asc">Price — low to high</option>
          <option value="price_desc">Price — high to low</option>
        </select>
      </div>
    </aside>
  );
}
