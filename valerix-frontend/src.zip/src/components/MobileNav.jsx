import React from "react";
import { Link } from "react-router-dom";
import { Home, ShoppingCart, User, MessageSquare } from "lucide-react";

export default function MobileNav() {
  return (
    <nav className="md:hidden fixed bottom-4 left-1/2 -translate-x-1/2
      bg-[rgba(8,16,24,0.92)] backdrop-blur-lg
      border border-[rgba(255,106,0,0.1)]
      rounded-full px-8 py-3 flex items-center gap-8 z-40 shadow-xl">
      
      <Link to="/"><Home size={22} /></Link>
      <Link to="/products"><ShoppingCart size={22} /></Link>
      <Link to="/chat"><MessageSquare size={22} /></Link>
      <Link to="/login"><User size={22} /></Link>
    
    </nav>
  );
}
