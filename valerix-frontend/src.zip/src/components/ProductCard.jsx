import React from "react";
import { Link } from "react-router-dom";

export default function ProductCard({ product }) {
  return (
    <div className="bg-[#0f0f11] border border-zinc-800 p-3 rounded">
      <img src={product.images?.[0]?.url || "https://via.placeholder.com/400"} alt={product.name} className="w-full h-40 object-cover rounded" />
      <h3 className="text-lg mt-2 text-white">{product.name}</h3>
      <div className="flex items-center justify-between mt-2">
        <div className="text-sm text-zinc-400">₹{product.price}</div>
        <Link to={`/product/${product._id||product.id}`} className="text-xs px-3 py-1 bg-neon rounded">View</Link>
      </div>
    </div>
  );
}
