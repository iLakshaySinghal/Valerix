import React from "react";
import { Link } from "react-router-dom";
import { useAuthStore } from "../store/useAuthStore";

export default function Navbar() {
  const { user, clearAuth } = useAuthStore();
  return (
    <header className="bg-[var(--panel)] border-b border-zinc-800">
      <div className="container flex items-center justify-between py-3">
        <Link to="/home" className="flex items-center gap-3">
          <img src="/src/assets/valerix-logo.png" alt="Valerix" className="w-10 h-10" />
          <span className="text-xl font-bold text-neon">Valerix</span>
        </Link>

        <nav className="flex items-center gap-4">
          <Link to="/products" className="hover:underline">Products</Link>
          <Link to="/cart" className="hover:underline">Cart</Link>
          {user ? (
            <>
              <span className="text-sm">{user.email?.split("@")[0]}</span>
              <button onClick={() => clearAuth()} className="px-3 py-1 bg-zinc-700 rounded">Logout</button>
            </>
          ) : (
            <Link to="/auth/request-otp" className="px-3 py-1 bg-zinc-700 rounded">Login</Link>
          )}
        </nav>
      </div>
    </header>
  );
}
