import React from "react";
import { useCartStore } from "../stores/cartStore.js";
import { Link } from "react-router-dom";

export default function CartDrawer() {
  const items = useCartStore((s) => s.items);
  const remove = useCartStore((s) => s.remove);
  const total = items.reduce((s, i) => s + i.price * i.qty, 0);

  if (!items || items.length === 0) return null;

  return (
    <div className="fixed right-4 bottom-4 w-96 p-4 bg-[rgba(8,16,24,0.95)] rounded-2xl shadow-2xl border border-[rgba(255,106,0,0.04)] z-50">
      <h4 className="font-semibold">Cart</h4>
      <div className="mt-2 max-h-64 overflow-auto">
        {items.map((it) => (
          <div key={it.productId} className="flex items-center justify-between py-2 border-b border-[rgba(255,255,255,0.02)]">
            <div>
              <div className="font-medium">{it.title}</div>
              <div className="text-sm opacity-60">Qty: {it.qty}</div>
            </div>
            <div className="text-right">
              <div>₹{it.price * it.qty}</div>
              <button onClick={() => remove(it.productId)} className="text-xs mt-2 underline">
                Remove
              </button>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-4 text-right">
        <div className="font-semibold">Total: ₹{total}</div>
        <Link to="/checkout" className="inline-block mt-2 px-3 py-2 rounded bg-[var(--accent)] text-black">
          Checkout
        </Link>
      </div>
    </div>
  );
}
