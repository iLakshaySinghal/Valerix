export default function Skeleton({ className = "" }) {
  return (
    <div className={`animate-pulse bg-[rgba(255,255,255,0.05)] rounded ${className}`}></div>
  );
}
