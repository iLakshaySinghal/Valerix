import React from "react";
import { Link, useLocation } from "react-router-dom";

export default function Sidebar() {
  const { pathname } = useLocation();

  const linkClass = (p) =>
    `block px-4 py-2 rounded-lg mb-2 ${
      pathname.includes(p)
        ? "bg-[var(--accent)] text-black"
        : "hover:bg-[rgba(255,106,0,0.08)]"
    }`;

  return (
    <aside className="w-64 bg-[rgba(8,16,24,0.9)] border-r border-[rgba(255,106,0,0.1)] p-6">
      <h3 className="text-xl font-bold mb-4">Dashboard</h3>

      <Link className={linkClass("products")} to="/startup/products">
        Products
      </Link>

      <Link className={linkClass("orders")} to="/startup/orders">
        Orders
      </Link>

      <Link className={linkClass("settings")} to="/startup/settings">
        Settings
      </Link>
    </aside>
  );
}
