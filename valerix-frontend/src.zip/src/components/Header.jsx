import React, { useState } from "react";
import { Link } from "react-router-dom";
import Dropdown, { DropdownItem } from "./ui/dropdown";
import Button from "./ui/button";
import Sheet from "./ui/sheet";
import { useAuthStore } from "../stores/useAuthStore.js";
import { Menu, ShoppingCart, User } from "lucide-react";

export default function Header() {
  const user = useAuthStore((s) => s.user);
  const clear = useAuthStore((s) => s.clear);

  const [sheetOpen, setSheetOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 bg-[rgba(8,16,24,0.85)] backdrop-blur-md border-b border-[rgba(255,106,0,0.05)] p-4 flex justify-between items-center">
      <Link className="text-2xl font-bold text-[var(--accent)]" to="/">
        Valerix
      </Link>

      {/* Desktop nav */}
      <div className="hidden md:flex gap-6 items-center">
        <Link to="/">Home</Link>
        <Link to="/products">Products</Link>
        <Link to="/chat">Chat</Link>
        <Link to="/cart"><ShoppingCart size={20} /></Link>

        {user ? (
          <Dropdown trigger={<Button className="px-3"><User size={18} /></Button>}>
            <DropdownItem onClick={() => (window.location = "/orders")}>My Orders</DropdownItem>
            <DropdownItem onClick={() => { clear(); window.location = "/login"; }}>Logout</DropdownItem>
          </Dropdown>
        ) : (
          <Button onClick={() => (window.location = "/login")}>Login</Button>
        )}
      </div>

      {/* Mobile menu */}
      <button className="md:hidden" onClick={() => setSheetOpen(true)}>
        <Menu size={24} />
      </button>

      <Sheet open={sheetOpen} onClose={() => setSheetOpen(false)}>
        <div className="flex flex-col gap-4 text-lg">
          <Link to="/" onClick={() => setSheetOpen(false)}>Home</Link>
          <Link to="/products" onClick={() => setSheetOpen(false)}>Products</Link>
          <Link to="/cart" onClick={() => setSheetOpen(false)}>Cart</Link>
          <Link to="/chat" onClick={() => setSheetOpen(false)}>Chat</Link>
          {user ? (
            <button onClick={() => { clear(); window.location="/login"; }}>Logout</button>
          ) : (
            <button onClick={() => (window.location="/login")}>Login</button>
          )}
        </div>
      </Sheet>
    </header>
  );
}
