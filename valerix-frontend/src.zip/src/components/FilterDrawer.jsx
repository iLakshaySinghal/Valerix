import React from "react";
import Sheet from "./ui/sheet";

export default function FilterDrawer({ open, onClose, onChange }) {
  return (
    <Sheet open={open} onClose={onClose}>
      <h2 className="text-xl font-bold text-[var(--accent)] mb-4">Filters</h2>

      <label>Search</label>
      <input className="w-full p-2 rounded bg-[rgba(7,16,24,0.4)] mb-4" onChange={(e) => onChange({ q: e.target.value })} />

      <label>Category</label>
      <select className="w-full p-2 rounded bg-[rgba(7,16,24,0.4)] mb-4" onChange={(e) => onChange({ category: e.target.value })}>
        <option value="">All</option>
        <option value="tech">Tech</option>
        <option value="health">Health</option>
        <option value="home">Home</option>
      </select>

      <label>Sort</label>
      <select className="w-full p-2 rounded bg-[rgba(7,16,24,0.4)]" onChange={(e) => onChange({ sort: e.target.value })}>
        <option value="">Recommended</option>
        <option value="price_asc">Price: Low → High</option>
        <option value="price_desc">Price: High → Low</option>
      </select>
    </Sheet>
  );
}
