import React, { useEffect, useState } from "react";
import useSocket from "../hooks/useSocket.js";
import { useAuthStore } from "../stores/useAuthStore.js";

export default function ChatBox({ room, compact = false }) {
  const socket = useSocket();
  const me = useAuthStore((s) => s.user);
  const [messages, setMessages] = useState([]);
  const [text, setText] = useState("");

  useEffect(() => {
    if (!socket) return;
    socket.emit("join", { room });
    socket.on("message", (m) => setMessages((s) => [...s, m]));
    return () => {
      socket.off("message");
      socket.emit("leave", { room });
    };
  }, [socket, room]);

  const send = () => {
    if (!text.trim()) return;
    const payload = { room, text, from: me?.name || "anonymous" };
    socket.emit("message", payload);
    setMessages((s) => [...s, payload]);
    setText("");
  };

  return (
    <div className={`p-4 bg-[rgba(6,16,23,0.9)] rounded-lg ${compact ? "w-full" : "w-full max-w-xl"}`}>
      <div className="h-64 overflow-auto mb-2">
        {messages.map((m, i) => (
          <div key={i} className="mb-2">
            <b className="mr-2 text-sm opacity-80">{m.from || "User"}:</b> <span>{m.text}</span>
          </div>
        ))}
      </div>

      <div className="flex gap-2">
        <input value={text} onChange={(e) => setText(e.target.value)} className="flex-1 p-2 rounded bg-[rgba(7,16,24,0.4)]" />
        <button onClick={send} className="px-4 py-2 rounded bg-[var(--accent)] text-black">
          Send
        </button>
      </div>
    </div>
  );
}
