import React from "react";
import { motion } from "framer-motion";

export default function Modal({ open, onClose, children }) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50">
      <motion.div
        initial={{ opacity: 0, y: 40 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0 }}
        className="bg-[rgba(8,16,24,0.9)] p-6 rounded-xl w-[90%] max-w-md shadow-xl border border-[rgba(255,106,0,0.06)]"
      >
        {children}
        <button onClick={onClose} className="mt-4 px-3 py-2 w-full bg-[var(--accent)] rounded text-black">
          Close
        </button>
      </motion.div>
    </div>
  );
}
