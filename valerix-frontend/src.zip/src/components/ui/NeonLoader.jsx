import React from "react";
import { motion } from "framer-motion";

export default function NeonLoader() {
  return (
    <motion.div
      className="fixed top-0 left-0 w-full h-[3px] bg-[var(--accent)] z-50 shadow-[0_0_12px_var(--accent)]"
      initial={{ scaleX: 0 }}
      animate={{ scaleX: 1 }}
      exit={{ scaleX: 0 }}
      transition={{ duration: 0.6, ease: "easeInOut" }}
      style={{ transformOrigin: "0% 50%" }}
    />
  );
}
