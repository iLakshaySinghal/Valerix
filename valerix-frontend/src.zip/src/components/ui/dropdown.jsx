import React, { useState, useRef, useEffect } from "react";

export default function Dropdown({ trigger, children }) {
  const [open, setOpen] = useState(false);
  const ref = useRef(null);

  useEffect(() => {
    const close = (e) => {
      if (ref.current && !ref.current.contains(e.target)) setOpen(false);
    };
    document.addEventListener("mousedown", close);
    return () => document.removeEventListener("mousedown", close);
  }, []);

  return (
    <div className="relative inline-block" ref={ref}>
      <div onClick={() => setOpen((v) => !v)}>{trigger}</div>

      {open && (
        <div className="absolute mt-2 right-0 bg-[rgba(8,16,24,0.92)] rounded-lg shadow-xl py-2 border border-[rgba(255,106,0,0.1)] min-w-[160px] z-40">
          {children}
        </div>
      )}
    </div>
  );
}

export const DropdownItem = ({ children, onClick }) => (
  <button
    onClick={onClick}
    className="block w-full text-left px-4 py-2 text-sm hover:bg-[rgba(255,106,0,0.08)] transition"
  >
    {children}
  </button>
);
