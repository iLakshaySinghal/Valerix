import React from "react";

export default function Input({ className = "", ...props }) {
  return (
    <input
      className={`w-full p-2 rounded bg-[rgba(8,16,24,0.5)] border border-[rgba(255,255,255,0.05)] focus:outline-none focus:ring-2 focus:ring-[var(--accent)] transition ${className}`}
      {...props}
    />
  );
}
