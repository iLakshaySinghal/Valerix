import React from "react";
import { motion } from "framer-motion";

export default function Button({ children, className = "", ...props }) {
  return (
    <motion.button
      whileTap={{ scale: 0.95 }}
      whileHover={{ scale: 1.03 }}
      className={`px-4 py-2 rounded-lg bg-[var(--accent)] text-black font-semibold shadow-md hover:shadow-[0_0_12px_var(--accent)] transition-all ${className}`}
      {...props}
    >
      {children}
    </motion.button>
  );
}
