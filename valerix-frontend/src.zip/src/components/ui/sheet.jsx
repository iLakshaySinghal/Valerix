import React from "react";
import { motion } from "framer-motion";

export default function Sheet({ open, onClose, children }) {
  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex">
      <div
        className="flex-1 bg-black/50"
        onClick={onClose}
      />

      <motion.div
        initial={{ x: 320 }}
        animate={{ x: 0 }}
        exit={{ x: 320 }}
        transition={{ type: "spring", stiffness: 120, damping: 20 }}
        className="w-80 bg-[rgba(8,16,24,0.95)] border-l border-[rgba(255,106,0,0.08)] p-6 shadow-xl"
      >
        {children}
      </motion.div>
    </div>
  );
}
