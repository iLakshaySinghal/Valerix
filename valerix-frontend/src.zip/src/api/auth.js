import api from "../utils/api";

export const requestOTP = (payload) => api.post("/auth/request-otp", payload);
export const verifyOTP = (payload) => api.post("/auth/verify-otp", payload);
