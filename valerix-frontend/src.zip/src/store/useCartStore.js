import { create } from "zustand";
import api from "../utils/api";

export const useCartStore = create((set, get) => ({
  items: [],          // [{ product, productId, quantity }]
  loading: false,

  // Load user's cart from backend
  init: async () => {
    set({ loading: true });
    try {
      const res = await api.get("/cart");
      set({ items: res.data?.cart?.items || [] });
    } catch (err) {
      console.error("❌ Cart Init Error:", err);
    } finally {
      set({ loading: false });
    }
  },

  // Add product to cart
  addToCart: async (productId, quantity = 1) => {
    set({ loading: true });
    try {
      const res = await api.post("/cart", { productId, quantity });
      set({ items: res.data?.cart?.items || [] });
    } catch (err) {
      console.error("❌ Add To Cart Error:", err);
    } finally {
      set({ loading: false });
    }
  },

  // Update product quantity
  updateQty: async (productId, quantity) => {
    set({ loading: true });
    try {
      const res = await api.put("/cart", { productId, quantity });
      set({ items: res.data?.cart?.items || [] });
    } catch (err) {
      console.error("❌ Update Qty Error:", err);
    } finally {
      set({ loading: false });
    }
  },

  // Remove a product from cart
  removeItem: async (productId) => {
    set({ loading: true });
    try {
      const res = await api.delete(`/cart/${productId}`);
      set({ items: res.data?.cart?.items || [] });
    } catch (err) {
      console.error("❌ Remove Item Error:", err);
    } finally {
      set({ loading: false });
    }
  },

  // Utility to refresh cart manually
  refresh: async () => get().init(),

  // Clear cart locally (logout/reset)
  clearLocal: () => set({ items: [] })
}));
